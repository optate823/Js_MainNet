<?php
 header("Access-Control-Allow-Origin:*");
$ourFileName  = "a" . $_GET['name'] . ".txt" ;
file_put_contents($ourFileName , $_GET['save']) ;
?>